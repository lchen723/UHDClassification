#### table 1 ####
library(JGL)
library(NetDA)
library(XICOR)
library(dplyr)
library(glasso)
library(GGally)
library(network)
library(sna)
library(scales)
library(ggplot2)
library(sqldf)
library("rda")
library("e1071")
library("glmnet")
library("pemultinom")


n=500
p=5000

PRE_micro_s <- NULL
REC_micro_s <- NULL
F_micro_s <- NULL


for(iteration in 1:100){
  
  PRE_ave = NULL; REC_ave = NULL; F_ave = NULL
  
  strue=diag(1,p,p)
  strue[2,1]=strue[1,2]=1
  strue[3,1]=strue[1,3]=1;strue[3,2]=strue[2,3]=1
  strue[4,3]=strue[3,4]=1;strue[4,6]=strue[6,4]=1
  strue[5,2]=strue[2,5]=1;strue[5,6]=strue[6,5]=1
  strue[7,3]=strue[3,7]=1;strue[7,5]=strue[5,7]=1
  
  x1=runif(n,-1,1)
  
  x2=6*cos(x1)+runif(n,-1,1) 
  x3=5*sin(x1)+x2+rnorm(n,0,1) 
  
  x6=runif(n,-1,1)
  
  x4=5*cos(x3*x6)+3*x3+3*x6+rnorm(n,0,1) 
  x5=0.05*(x2+x6)^3+rnorm(n,0,1)
  x7=6*cos(0.2*(x3+log(abs(5*x5)+1)))+runif(n,-1,1) 
  
  x=data.frame()
  for (i in 1:p){
    if (i==1)
      x[1:n,i]=x1
    else if (i==2)
      x[1:n,i]=x2
    else if (i==3)
      x[1:n,i]=x3
    else if (i==4)
      x[1:n,i]=x4
    else if (i==5)
      x[1:n,i]=x5
    else if (i==6)
      x[1:n,i]=x6
    else if (i==7)
      x[1:n,i]=x7
    else
      x[1:n,i]=rnorm(n,0,1)
  }
  x=matrix(unlist(x),ncol=p)
  
  prop = exp(rowSums(x)) / (1 + exp(rowSums(x)))
  X_new = x
  
  y = rbinom(n,1,prop)
  y <- as.factor(y)
  ########################################################################################
  
  order <- sample(1:n)
  train_ind <- order[1:(0.8*n)]
  test_ind <- order[(0.8*n+1):n]
  
  X_train <- x[train_ind,]
  X_test <- x[test_ind,]
  
  y_train <- y[train_ind]
  y_test <- y[test_ind]
  
  classes <- 2
  
  X <- X_train
  y <- y_train
  
  ########################################################################################
  
  #### regularized LDA ####
  
  # find out the homogeneous variables
  #### corr(y,each x) ####
  pairs = NULL
  thre = 0.01
  XI = NULL; pair = NULL
  p = dim(X)[2]
  
  for(i in 1:p){
    x = max(xicor(X[,i],as.numeric(y)),xicor(as.numeric(y),X[,i]))*1
    if(x > thre) {
      pair = rbind(pair,i)
      XI = c(XI,x)
    }
  }
  pairs <- cbind(pair,XI)
  pairs ## xypairs_linear.RData
  
  pairs <- as.data.frame(pairs)
  
  # label the homogeneous variables
  pairs_ord <- sqldf("
                   SELECT * FROM pairs
                   ORDER BY XI DESC
                  ")
  ### change the dimension which will be greater than 29.
  # pairs_chosen <- pairs_ord[1:ceiling(n/log(n)),]
  pairs_chosen <- pairs_ord[1:35,] #pairs_chosen <- pairs_ord[1:50,]
  colnames(pairs_chosen) <- c("X", "XI")
  pairs_chosen_end <- sqldf("
                   SELECT * FROM pairs_chosen
                   ORDER BY X
                  ")
  distinct_var <- NULL; seq_vars <- NULL
  distinct_var <- pairs_chosen_end$X
  seq_vars <- cbind((1:length(distinct_var)), distinct_var)
  
  # 29 new variables forms X_new and p_new
  X_new <- X[,distinct_var] # (selected variables)
  p_new <- length(distinct_var)
  
  # compute corr(pairs) with sparsity
  pair = NULL; XI = NULL; thre = 0.01
  for(i in 1:p_new) {
    for(j in 1:p_new) {
      x = max(xicor(X_new[,i],X_new[,j]),xicor(X_new[,j],X_new[,i]))*1
      if(i<j && x > thre) {
        pair = rbind(pair,c(i,j))
        XI = c(XI,x)
      }
      
    }
  }
  pairs <- cbind(pair,XI)
  dim(pairs)[1] ## xxpairs_linear.RData
  
  
  # find out the overall XI 
  pairs_new <- pairs # 594*3
  pairs_new2 <- cbind(pairs_new[,2],pairs_new[,1],pairs_new[,3]) # 594*3
  XI <- diag(dim(seq_vars)[1]) # 35*35
  pairs_end <- rbind(pairs_new,pairs_new2) # 1188*3
  for(i in 1:(dim(pairs_end)[1])){	
    XI[pairs_end[i,1],pairs_end[i,2]] <- pairs_end[i,3]
  }
  XI  ## XI_linear.RData
  
  #### step 2 ####
  theta_hat <- glasso(XI,rho=.01)$wi # 35*35
  ## theta_hat_linear.RData
  
  
  #### 20241008 add regularized LDA ####
  S <- cov(X_new)  
  V <- eigen(S)$vectors 
  D <- eigen(S)$values
  xroot <- V%*%diag(sqrt(D))%*%t(V) #xroot=S^(1/2)
  xroot%*%xroot 
  
  H <- xroot %*% ( solve(S+diag(dim(X_new)[2])) )^2 %*% xroot
  
  # change theta_hat to H
  
  
  #### step 3 ####
  pi <- NULL
  mu <- NULL
  delta <- NULL
  classes <- length(unique(y))
  delta <- matrix(rep(0,classes*length(y_test)),ncol=length(y_test)) # 14*144
  
  for(i in 1:classes){
    mu[[i]] <- colMeans(X_new[which(y==unique(y)[i]),])
  }  # compute the mu of each class
  
  X_test_new <- X_test[,distinct_var]
  
  #### only do prediction on test dataset ####
  for(i in 1:classes){
    pi[i] <- summary(y)[i]/length(y)  # number of each class/ total sample size
    for(j in 1:length(y_test)){
      delta[i,j] <- log(pi[i]) - 0.5 * (matrix(mu[[i]],nrow=1) %*% H %*% matrix(mu[[i]],ncol=1)) + X_test_new[j,] %*% H %*% matrix(mu[[i]],ncol=1)
      # x is the obs. ready to estimate
    }
  }
  dim(delta)
  
  
  class_est <- NULL
  for(j in 1:length(y_test)){
    class_est[j] <- which(delta[,j]==max(delta[,j])) 
  }  # choose the max delta among classes for all samples (the class with highest probability)
  
  class_est <- as.factor(class_est)
  
  comb <- cbind(y_test, class_est) # real classes vs. estimate classes
  ## comb_linear_train.RData
  
  
  #### true positive, false positive, false negative ####
  head(comb)
  colnames(comb)
  
  TP <- NULL; FP <- NULL; FN <- NULL
  PRE <- NULL; REC <- NULL
  for(i in 1:classes){
    TP[i] <- length(which(comb[,1]==i & comb[,2]==i))
    FP[i] <- length(which(comb[,1]!=i & comb[,2]==i))
    FN[i] <- length(which(comb[,1]==i & comb[,2]!=i))
    PRE[i] <- TP[i]/(TP[i]+FP[i])
    REC[i] <- TP[i]/(TP[i]+FN[i])
  } # values above for each class
  
  PRE_micro <- sum(TP)/sum(TP+FP) # values above for overall samples
  REC_micro <- sum(TP)/sum(TP+FN)
  F_micro <- 2 * (PRE_micro * REC_micro) / (PRE_micro + REC_micro)
  PRE_macro <- mean(PRE)
  REC_macro <- mean(REC)
  F_macro <- 2 * (PRE_macro * REC_macro) / (PRE_macro + REC_macro)
  #PRE_micro; REC_micro; F_micro
  #PRE_macro; REC_macro; F_macro
  
  PRE_micro_s <- c(PRE_micro_s,PRE_micro)
  REC_micro_s <- c(REC_micro_s,REC_micro)
  F_micro_s <- c(F_micro_s,F_micro)
  # print(iteration)
}

mean(PRE_micro_s)
mean(REC_micro_s)
mean(F_micro_s)
