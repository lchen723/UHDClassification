#### table 1 ####
library(JGL)
library(NetDA)
library(XICOR)
library(dplyr)
library(glasso)
library(GGally)
library(network)
library(sna)
library(scales)
library(ggplot2)
library(sqldf)
library("rda")
library("e1071")
library("glmnet")
library("pemultinom")

n=200
p=10000

PRE_micro_s <- NULL
REC_micro_s <- NULL
F_micro_s <- NULL


for(iteration in 1:100){
  
  PRE_ave = NULL; REC_ave = NULL; F_ave = NULL
  
  strue=diag(1,p,p)
  strue[2,1]=strue[1,2]=1
  strue[3,1]=strue[1,3]=1;strue[3,2]=strue[2,3]=1
  strue[4,3]=strue[3,4]=1;strue[4,6]=strue[6,4]=1
  strue[5,2]=strue[2,5]=1;strue[5,6]=strue[6,5]=1
  strue[7,3]=strue[3,7]=1;strue[7,5]=strue[5,7]=1
  
  x1=runif(n,-1,1)
  
  x2=6*cos(x1)+runif(n,-1,1) 
  x3=5*sin(x1)+x2+rnorm(n,0,1) 
  
  x6=runif(n,-1,1)
  
  x4=5*cos(x3*x6)+3*x3+3*x6+rnorm(n,0,1) 
  x5=0.05*(x2+x6)^3+rnorm(n,0,1) 
  x7=6*cos(0.2*(x3+log(abs(5*x5)+1)))+runif(n,-1,1) 
  
  x=data.frame()
  for (i in 1:p){
    if (i==1)
      x[1:n,i]=x1
    else if (i==2)
      x[1:n,i]=x2
    else if (i==3)
      x[1:n,i]=x3
    else if (i==4)
      x[1:n,i]=x4
    else if (i==5)
      x[1:n,i]=x5
    else if (i==6)
      x[1:n,i]=x6
    else if (i==7)
      x[1:n,i]=x7
    else
      x[1:n,i]=rnorm(n,0,1)
  }
  x=matrix(unlist(x),ncol=p)
  
  prop = exp(rowSums(x)) / (1 + exp(rowSums(x)))
  X_new = x
  
  y = rbinom(n,1,prop)
  ########################################################################################

  y <- as.factor(y)
  
  X <- x
  X_test <- x
  y_test <- y
  
  
  classes <- 2
  
  
  table(y)
  
  ########################################################################################
  
  #### naiveBayes ####
  fit <- naiveBayes(X, y)
  predict_Bayes <- predict(fit,X_test)
  
  comb <- cbind(y_test,predict_Bayes)
  
  # naiveBayes performance 
  TP <- NULL; FP <- NULL; FN <- NULL
  PRE <- NULL; REC <- NULL
  for(i in 1:classes){
    TP[i] <- length(which(y_test==i & predict_Bayes==i))
    FP[i] <- length(which(y_test!=i & predict_Bayes==i))
    FN[i] <- length(which(y_test==i & predict_Bayes!=i))
    PRE[i] <- TP[i]/(TP[i]+FP[i])
    REC[i] <- TP[i]/(TP[i]+FN[i])
  }
  PRE_micro <- sum(TP)/sum(TP+FP)
  REC_micro <- sum(TP)/sum(TP+FN)
  F_micro <- 2 * (PRE_micro * REC_micro) / (PRE_micro + REC_micro)
  PRE_macro <- mean(PRE)
  REC_macro <- mean(REC)
  F_macro <- 2 * (PRE_macro * REC_macro) / (PRE_macro + REC_macro)
  #PRE_micro; REC_micro; F_micro
  #PRE_macro; REC_macro; F_macro
  
  PRE_micro_s <- c(PRE_micro_s,PRE_micro)
  REC_micro_s <- c(REC_micro_s,REC_micro)
  F_micro_s <- c(F_micro_s,F_micro)
}

mean(PRE_micro_s)
mean(REC_micro_s)
mean(F_micro_s)
